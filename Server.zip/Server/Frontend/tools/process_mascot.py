﻿"""Pencil sketch -> dark-theme hero.
The figure is cut out of the paper (silhouette mask) and recoloured with a tritone gradient map:
paper -> white / light gray, graphite mid-tones -> green, heavy graphite -> dark gray.
Outside the silhouette is the page background, so the image blends into the site."""
import sys
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

src, outdir = sys.argv[1], sys.argv[2]
BG = (0x1c, 0x1e, 0x1c)  # must match --color-bg in css/tokens.css

im = Image.open(src).convert("L").crop((640, 236, 1000, 758))
SCALE = 2
im = im.resize((im.width * SCALE, im.height * SCALE), Image.LANCZOS)
g = np.asarray(im, np.float32)

# remove uneven lighting of the paper
paper = np.asarray(im.filter(ImageFilter.MaxFilter(15)).filter(ImageFilter.GaussianBlur(40)), np.float32)
ink = np.clip(1.0 - g / np.maximum(paper, 1), 0, 1)
lo, hi = np.percentile(ink, 30), np.percentile(ink, 99.8)
ink = np.clip((ink - lo) / (hi - lo), 0, 1)

def L(a): return Image.fromarray(np.clip(a * 255, 0, 255).astype(np.uint8))
def A(im): return np.asarray(im, np.float32) / 255

# --- silhouette mask: strokes -> close gaps -> fill everything not reachable from the border
strokes = A(L(ink).filter(ImageFilter.GaussianBlur(2))) > .22
m = L(strokes.astype(np.float32))
for _ in range(3): m = m.filter(ImageFilter.MaxFilter(9))
m = m.point(lambda v: 255 if v > 127 else 0)
h, w = ink.shape
canvas = Image.new("L", (w + 2, h + 2), 0)
canvas.paste(m, (1, 1))
ImageDraw.floodfill(canvas, (0, 0), 128)            # outside region
# the gap between waist and the arm on the hip is background too
gap = (1 + 480, 1 + 690)
if canvas.getpixel(gap) == 0:
    ImageDraw.floodfill(canvas, gap, 128)
canvas = canvas.crop((1, 1, w + 1, h + 1))
mask = canvas.point(lambda v: 0 if v == 128 else 255)
# keep only the component connected to the figure (drops stray specks on the paper)
ImageDraw.floodfill(mask, (360, 120), 200)
mask = mask.point(lambda v: 255 if v == 200 else 0)
for _ in range(3): mask = mask.filter(ImageFilter.MinFilter(9))
# smooth the blocky edges left by the morphology, then feather
mask = mask.filter(ImageFilter.GaussianBlur(7)).point(lambda v: 255 if v > 127 else 0)
mask = A(mask.filter(ImageFilter.GaussianBlur(3)))

# --- tritone gradient map (Material green around #55aa42)
stops = [
    (0.00, (0xe8, 0xec, 0xe6)),   # white accent (paper / skin)
    (0.28, (0xbd, 0xc4, 0xba)),   # light gray
    (0.52, (0x7d, 0xb8, 0x6d)),   # light green
    (0.70, (0x55, 0xaa, 0x42)),   # brand #55aa42
    (0.86, (0x33, 0x6e, 0x29)),   # green 800
    (1.00, (0x26, 0x2b, 0x26)),   # dark gray
]
xs = np.array([s[0] for s in stops])
fig = np.stack([np.interp(ink, xs, [s[1][c] for s in stops]) for c in range(3)], axis=-1)

# fade bottom (paper edge) and sides into background
yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
def ramp(d, size):
    t = np.clip(d / size, 0, 1); return t * t * (3 - 2 * t)
fade = ramp(h - 1 - yy, h * .2) * ramp(yy, h * .02)
alpha = (mask * fade)[..., None]

# subtle green glow around the silhouette
glow = A(L(mask * fade).filter(ImageFilter.GaussianBlur(26)))[..., None] * .35
bg = np.array(BG, np.float32) * (1 - glow) + np.array((0x2e, 0x6b, 0x25), np.float32) * glow
rgb = fig * alpha + bg * (1 - alpha)

out = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8))
out = out.filter(ImageFilter.UnsharpMask(radius=1.2, percent=50, threshold=2))
for width in (720, 480):
    r = out if width == out.width else out.resize((width, round(out.height * width / out.width)), Image.LANCZOS)
    r.save(f"{outdir}/mascot-{width}.webp", quality=80, method=6)
    r.save(f"{outdir}/mascot-{width}.jpg", quality=82, optimize=True, progressive=True)
