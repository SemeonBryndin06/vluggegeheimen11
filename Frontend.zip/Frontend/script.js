// Находим элементы на странице
const button = document.getElementById('btn');
const counterSpan = document.getElementById('counter');

// Создаем переменную для хранения числа
let count = 0;

// Добавляем обработчик клика по кнопке
button.addEventListener('click', () => {
    count++; // увеличиваем число на 1
    counterSpan.textContent = count; // выводим новое значение в span
});